package com.capgemini.user.service;

import java.util.List;

import com.capgemini.user.bean.User;
import com.capgemini.user.exception.UserException;

public interface UserService {
	List<User> createNewUser(User userdtls) throws UserException;

	List<User> deleteUser(int id) throws UserException;

	List<User> listUsers() throws UserException;

	User getUserById(int id) throws UserException;

	List<User> editUser(User userdtls, int id) throws UserException;
}

package com.capgemini.user.exception;

public class UserException extends Exception {
	public UserException() {
		super();
		
	}

	public UserException(String msg) {
		super(msg);
	
	}

}

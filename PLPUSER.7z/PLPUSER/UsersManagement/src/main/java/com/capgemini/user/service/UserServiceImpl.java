package com.capgemini.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.user.bean.User;
import com.capgemini.user.dao.UserDao;
import com.capgemini.user.exception.UserException;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao userDao;

	@Override
	public List<User> createNewUser(User userdtls) throws UserException {
		userDao.save(userdtls);
		return listUsers();
	}

	@Override
	public List<User> deleteUser(int id) throws UserException {
		if (userDao.existsById(id)) {
			userDao.deleteById(id);
			return listUsers();
		} else {
			throw new UserException("User with id " + id + " does not exist");
		}
	}

	@Override
	public List<User> listUsers() throws UserException {

		return userDao.findAll();

	}

	@Override
	public User getUserById(int id) throws UserException {
		return userDao.findById(id).get();
	}

	@Override
	public List<User> editUser(User userdtls, int id) throws UserException {
		if (userDao.existsById(id)) {
			User user1=userDao.findById(id).get();
			user1.setEmail(userdtls.getEmail());
			user1.setFullName(userdtls.getFullName());
			user1.setPassword(userdtls.getPassword());
			userDao.save(user1);
			return listUsers();
		} else {
			throw new UserException("Invalid User, cannot be updated");
		}
	}

}

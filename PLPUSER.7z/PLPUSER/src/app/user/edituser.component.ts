import { Component, OnInit } from '@angular/core';
import { User } from '../model/user.interface';
import { UserService } from './user.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {

  // constructor() { }

  // ngOnInit() {
  // }


  userData: User = { "id": 0, "email": '', "fullName": '', "password": '' };
  constructor(private userService: UserService,
    private router: Router, private route: ActivatedRoute) { }



  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.userService.getUser(params['id'])
      .subscribe((result) => { this.userData = result; })
    })

  }
  edit(){
    console.log(this.userData.id);
    this.userService.editUser(this.userData).subscribe(data=>{this.router.navigate([''])});
  }
//  createUser(){
//   console.log(this.userData.fullName);
//   this.userService.createUser(this.userData).subscribe(data=>{this.router.navigate([''])});
}


